root="https://www.testpapersfree.com/maths/index.php?level=P4&year=%&subject=Maths&type=%&school=%&Submit=Show%20Test%20Papers&page="
startIdx=1
endIdx=28
sub=math
class=p4
while test $startIdx -le $endIdx
do
    url="$root$startIdx"
    wget -O $sub_$class.$startIdx $url
    startIdx=`expr $startIdx + 1`
done

