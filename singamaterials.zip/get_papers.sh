#!/bin/bash
BASEURL="http://www.testpapersfree.com/"

nLines=`wc -l questionpaper_url.list|cut -d " " -f1`
idx=1
echo $nLines
while test $idx -le $nLines
do
	currLine=`head -$idx questionpaper_url.list|tail -1`
	isValidURL=`echo $currLine | grep -c "^http"`
	if test $isValidURL -eq 1
	then
		echo Processing $currLine
		wget "$currLine" -O tmp
		fgrep "show.php" tmp | grep href | cut -d '"' -f2 | cut -d "/" -f2 > paper_urls.src
		paperCount=`wc -l paper_urls.src|cut -d " " -f1`
		j=1
		while test $j -le $paperCount
		do
			currRow=`head -$j paper_urls.src|tail -1`
			downloadURL=${BASEURL}${currRow}
			echo Processing $downloadURL
			wget ${downloadURL} -O tmp_3
			pdf_file=`grep pdfs tmp_3 | grep pdf | cut -d '"' -f6`
			#echo BINGO=${BASEURL}${pdf_file}
			wget ${BASEURL}${pdf_file}
			j=`expr $j + 1`
		done
	fi	
	idx=`expr $idx + 1`
done
